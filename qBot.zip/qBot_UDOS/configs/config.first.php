<?php
$language = 'PL';
//Do wyboru:
//PL, EN
?>
